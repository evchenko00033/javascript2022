  // Створити масив, наповнити його 10 елементами будь-якого типу, вивести кожен елемент в консоль

  let list = [
      "bucket", 'mop', 'adhesive_tape', 'glue', 'washing_powder', 'eggs', 'flour', 'bread', 'butter', 'milk'
  ];
  console.log(list);

// - Створити 3 об'єкти які описують книги. Поля об'єкту : title ,pageCount, genre.

  let book1 = {title:'Fdgfhdfghhg', pageCount:  253, genre: 'Fiction'};
  let book2 = {title: 'Dhfgh', pageCount: 452, genre: 'Non'};
  let book3 = {title: 'Hkyhkyui', pageCount: 546, genre: 'Light_fiction'};


// - Створити 3 об'єкти які описують книги. Поля об'єкту : title ,pageCount, genre, authors. Поле "автори" - масив.
  // Кожен автор має поля name,age


  let book4 = {title:'Fdgfhdfghhg', pageCount:  253, genre: 'Fiction',authors:[name='Lesya_Ukrainka',age=154]};
  let book5 = {title: 'Dhfgh', pageCount: 452, genre: 'Non',authors:[name='Taras_Shevchenko',age=546]};
  let book6 = {title: 'Hkyhkyui', pageCount: 546, genre: 'Light_fiction',authors:[name='Ivan_Kotlyarvsky',age=-564]};



// - Створити масив з 10 об'єктами які описують сутніть "користувач". Поля: name, username,password.
  // Вивести в консоль пароль кожного користувача
  let users = [
    {name: 'Fhgfh', username: 'Hfdfgh', password: 'dfghgf215+6'},
    {name: 'Llkj', username: 'Kfghfh', password: 'dfghgj7s84'},
    {name: 'Flkjlkj', username: 'Dhjghj', password: 'dhfd_jhhg6'},
    {name: 'Joklnl', username: 'Rhkjhkgh', password: '665463131'},
    {name: 'Fibbkll', username: 'Lghj', password: 'jhgfhgj9f907'},
    {name: 'Gkjhv', username: 'Oghjghjg', password: 'dfghj5+6'},
    {name: 'Gjhgf', username: 'Rjghjfhg', password: 'fghjjjj215+6'},
    {name: 'Ffhj', username: 'Qfghgfh', password: 'dfghgf456456465'},
    {name: 'Fhfhd', username: 'Lfghfgh', password: 'dfgh4578'},
    {name: 'Kfghfg', username: 'Dhggfghj', password: 'd454kkgf215+6'}
  ];
  // console.log(users [0].password) ;
  // console.log(users [1].password) ;
  // console.log(users [2].password) ;
  // console.log(users [3].password) ;
  // console.log(users [4].password) ;
  // console.log(users [5].password) ;
  // console.log(users [6].password) ;
  // console.log(users [7].password) ;
  // console.log(users [8].password) ;
  // console.log(users [9].password) ;


  console.log(users [0]['password']) ;
  console.log(users [1]['password']) ;
  console.log(users [2]['password']) ;
  console.log(users [3]['password']) ;
  console.log(users [4]['password']) ;
  console.log(users [5]['password']) ;
  console.log(users [6]['password']) ;
  console.log(users [7]['password']) ;
  console.log(users [8]['password']) ;
  console.log(users [9]['password']) ;




